# html_ts_boilerplate
To start coding open your terminal and write
```
npm i
```

When all packages have been installed run:
```
npm start
```
