#!/bin/bash
json-server --watch db.json --port 3004
